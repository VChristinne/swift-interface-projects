//
//  app_shoe_prototypeApp.swift
//  app-shoe-prototype
//
//  Created by Vanessa Christinne on 09/08/2023.
//

import SwiftUI

@main
struct app_shoe_prototypeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
